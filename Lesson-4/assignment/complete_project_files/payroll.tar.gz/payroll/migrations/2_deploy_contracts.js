var SimpleStorage = artifacts.require("./SimpleStorage.sol");
// deploy payroll contract
var Payroll = artifacts.require("./Payroll.sol")

module.exports = function(deployer) {
  deployer.deploy(SimpleStorage);
  deployer.deploy(Payroll);
};
